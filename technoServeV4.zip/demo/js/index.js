

var serverURL ="http://localhost:5000/";
var ordersData;
var vaData;
var farmerData;
var dashboardData;

// Calculate age from date of birth
function getAge(dob){

	// if only year is sent
	if($.isNumeric(dob)) {
		var now = new Date();
		var age =now.getFullYear() - dob;
		return age;
	}

	// if full date is sent
	if(jQuery.type(dob)==="date"){
		mydob = new Date(dob);
		var today = new Date();
		var age = Math.floor((today-mydob) / (365.25 * 24 * 60 * 60 * 1000));
		return age;
	}

	// if format sent is neither date nor number
	else{
		return '18+'
	}
}
#import couchdb
#couch = couchdb.Server('http://Administrator:123456789@localhost:8091')

#db = couch.create('test_db')

#doc = {
#'id':4343434,
#'content':{
#    'person_name':'Cool Dude',
#    'email':'cool_dube@yahoo.com'
#    }
#}

#db.save(doc)
#from couchbase import Couchbase
#from couchbase.cluster import Cluster
#from couchbase.cluster import PasswordAuthenticator
#cluster = Cluster('couchbase://localhost')
#authenticator = PasswordAuthenticator('Administrator', '123456789')
#cluster.authenticate(authenticator)
#bucket = cluster.open_bucket('travel-sample')
#pip --version

#from couchbase.bucket import Bucket
#from couchbase.n1ql import N1QLQuery

# Connect to Couchbase
#bucket = Bucket('couchbase://localhost/default')
# Upsert a document in the bucket
#bucket.upsert("book1", {
#  "isbn": "978-1-4919-1889-0",
#  "name": "Minecraft Modding with Forge",
#  "cost": 29.99
#})

# retrieve and print the document
#print(bucket.get("book1").value)

#import couchdb
from couchbase.bucket import Bucket
from couchbase.n1ql import N1QLQuery
bucket = Bucket('couchbase://localhost/test-sample')

#bucket.upsert("book5", {
#  "isbn": "178-1-4919-1889-04",
#  "name": "Very Minecraft Modding with Forge",
#  "cost": 829.99
#})

# retrieve and print the document
#print(bucket.get("book5").value)

# retrieve and print all the documents
res = []
query = N1QLQuery("SELECT * FROM `test-sample`")
print(bucket.n1ql_query(query))
for row in bucket.n1ql_query(query):
    #print(row)
    res.extend(row)
print(res)

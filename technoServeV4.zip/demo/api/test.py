'''from couchbase.bucket import Bucket
from couchbase.n1ql import N1QLQuery
test_bucket = Bucket('couchbase://Administrator:akorion1803@159.65.195.115/test')

def get_three_vas():
    #global res
    res =[]
    query_test = N1QLQuery("SELECT * FROM `test` WHERE type='farmer' LIMIT 2")
    for row in va_bucket.n1ql_query(query_test):
        res.append(row)
    return res'''

#import couchdb
#couch = couchdb.Server("http://Administrator:akorion1803@159.65.195.115:8091/")
#db = couch["test"]
#db = couch.create('hello_db')
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.n1ql import N1QLQuery
cluster = Cluster('couchbase://159.65.195.115:8091/')
authenticator = PasswordAuthenticator('Administrator', 'akorion1803')
cluster.authenticate(authenticator)
bucket = cluster.open_bucket('test')
bucket2 = Bucket('couchbase://localhost/test')

tasks = [
    {
        'id': 1,
        'title': u'Buy groceries',
        'description': u'Milk, Cheese, Pizza, Fruit, Tylenol', 
        'done': False
    },
    {
        'id': 2,
        'title': u'Learn Python',
        'description': u'Need to find a good Python tutorial on the web', 
        'done': False
    }
]

def myTasks():
    res=[]
    query_va_female = N1QLQuery("SELECT COUNT(*) AS va_female_count FROM `test` WHERE type='va' AND partner_id='AK/DP/006' AND va_gender='Female' OR va_gender='female' OR va_gender='F' OR va_gender='f'")
    for row in bucket.n1ql_query(query_va_female):
        res.append(row['va_female_count'])

    return res

@app.route("/query_example")
def query_example():
    language = request.args.get('language') #if key doesn't exist, returns None
    framework = request.args['framework'] #if key doesn't exist, returns a 400, bad request error

    return '''<h1>The language value is: {}</h1>
    <h1>The framework value is: {}</h1>'''.format(language,framework)


@app.route('/form-example', methods=['GET', 'POST']) #allow both GET and POST requests
def form_example():
    if request.method == 'POST':  #this block is only entered when the form is submitted
        language = request.form.get('language')
        framework = request.form['framework']

        return '''<h1>The language value is: {}</h1>
                  <h1>The framework value is: {}</h1>'''.format(language, framework)

    return '''<form method="POST">
                  Language: <input type="text" name="language"><br>
                  Framework: <input type="text" name="framework"><br>
                  <input type="submit" value="Submit"><br>
              </form>'''

@app.route('/json-example', methods=['POST']) #GET requests will be blocked
def json_example():
    req_data = request.get_json()

    language = req_data['language']
    framework = req_data['framework']
    python_version = req_data['version_info']['python'] #two keys are needed because of the nested object
    example = req_data['examples'][0] #an index is needed because of the array
    boolean_test = req_data['boolean_test']

    return '''
           The language value is: {}
           The framework value is: {}
           The Python version is: {}
           The item at index 0 in the example list is: {}
           The boolean value is: {}'''.format(language, framework, python_version, example, boolean_test)



  





var serverURL ="http://localhost:5000/";
var ordersData;
var vaData;
var farmerData;
var dashboardData;
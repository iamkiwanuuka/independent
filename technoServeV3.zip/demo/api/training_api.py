from couchbase.n1ql import N1QLQuery
from config import serverBucket
bucket = serverBucket()
#farmer_bucket = Bucket('couchbase://localhost/farmer-bucket')


def add_new_training():
    return 0

def get_training_list():
    return 0



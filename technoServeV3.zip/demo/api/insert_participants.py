from couchbase.n1ql import N1QLQuery
from config import serverBucket,localBucket
bucket = localBucket()

doc = {
"agriculture_experience_in_years": "NA",
      "assets_held": "NA",
      "certification_doc_url": "NA",
      "education_doc_url": "NA",
      "education_level": "NA",
      "laId": "AK/LA/0001",
      "other_occupation": "NA",
      "partner_id": "AK/DP/0005",
      "position held_in_community": "NA",
      "service_provision_experience_in_years": "NA",
      "services_va_provides": "NA",
      "time": "2018-04-15T01:46:29:608505",
      "type": "va",
      "vaId": "AK/DP/0005/0001",
      "va_country": "Uganda",
      "va_district": "Kiruhura",
      "va_dob": "NA",
      "va_gender": "male",
      "va_home_gps_Accuracy": "NA",
      "va_home_gps_Altitude": "NA",
      "va_home_gps_Latitude": "NA",
      "va_home_gps_Longitude": "NA",
      "va_id_number": "Cm8906510148TG",
      "va_id_type": "national-id",
      "va_name": "MOSES MAGOGO",
      "va_parish": "MBABA",
      "va_phone_number": 779809969,
      "va_photo": "https://drive.google.com/open?id=1HotOsZbpk0jvgZ5LZgc1IpW7n-Anu3u8",
      "va_region": "Western",
      "va_subcounty": "Kazo",
      "va_village": "KENSINGA"
}

#bucket_id = "va124"
buck_id ="va_123"
def increment_bucket_id():
      query3 = N1QLQuery("SELECT META().id AS id FROM `va-bucket` ORDER BY id DESC LIMIT 1")
      for row in va_bucket.n1ql_query(query3):
            bucket_id = int(row['id'].split("_")[1])
      bucket_id +=1
      next_id ="va_"+str(bucket_id)
	#query3 = N1QLQuery("SELECT META().id AS id FROM `va-bucket` ORDER BY id DESC LIMIT 1")
	#for row in va_bucket.n1ql_query(query3):
		#bucket_id = int(row['id'].split("_")[1])
	#bucket_id ="va_123"
      #next_id ="va_"+str(bucket_id)
      return next_id

def save_new_va(data_doc):
      #doc2 = {"va_name": ag_name,"va_phone_number": ag_contact}
      if bucket.upsert("ydsfdsfgdfg",data_doc):
            return 'success'
      else:
            return 'failed'
from couchbase.n1ql import N1QLQuery
from config import serverBucket
bucket = serverBucket()
#farmer_bucket = Bucket('couchbase://localhost/farmer-bucket')


def get_order_totals():
    districts = {"Gulu","Lira","Amuru","Omoro","Arua"}
    res ={}
    total_orders = 0
    for distr in districts:
        query_district_orders = N1QLQuery("SELECT COUNT(*) AS distr_cnt FROM `va-bucket` WHERE type='order' AND district='%s' GROUP BY district" % distr)
        for row in bucket.n1ql_query(query_district_orders):
            res[distr]=row['distr_cnt']
            total_orders+=int(row['distr_cnt'])
    res['Total']=total_orders
    return res
    #return 1

def get_orders_by_agents():
    res =[]
    query_va = N1QLQuery("SELECT vaId, count(*) as num_of_orders, min(details.time) as fdate, max(details.time) as ldate  FROM `test` WHERE type='order' AND vaId like 'AK/DP/0006%' GROUP BY vaId")
    for row in bucket.n1ql_query(query_va):
        res.append(row)
    return res

def get_farmer_orders_per_agent():
    vaId = 'AK/DP/0006/0046'
    res =[]
    query_va = N1QLQuery("SELECT * FROM `test` WHERE type='order' AND vaId ='%s'" %vaId)
    for row in bucket.n1ql_query(query_va):
        res.append(row['test'])
    return res


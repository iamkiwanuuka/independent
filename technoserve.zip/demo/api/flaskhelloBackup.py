from flask import Flask, render_template,jsonify, request
from flask_cors import CORS
from couchbase.bucket import Bucket
from couchbase.n1ql import N1QLQuery

from test import myTasks
from fetch_dashboard_totals import get_dashboard_totals,get_vas_by_gender,get_farmers_by_gender,get_all_dashboard,get_agents_and_farmers_per_district
from insert_participants import save_new_va,increment_bucket_id
from fetch_participants import get_all_vas,get_all_farmers
from fetch_orders import get_order_totals
bucket = Bucket('couchbase://localhost/test-sample')


app = Flask(__name__)
CORS(app)


@app.route("/")
@app.route("/home")
def home():
    return jsonify({'tasks': myTasks()})
	#return render_template('farmerapi.py')
	#return jsonify(bucket.get("book5").value)
	#print ("Json")

#Route for retrieving dashboard totals'
@app.route("/dashboard_totals")
def dashboard_totals():
	response = jsonify(get_dashboard_totals())
	response.headers.add('Access-Control-Allow-Origin', '*')
	return response

#Route for saving farmers, vas, bcs'
@app.route("/save_participants", methods=["POST","GET"])
def save_participants():
	#rf = request.form
	#agent_name = request.GET['agent_name']
	#agent_contact = request.GET['agent_contact']
	return save_new_va()
    #return jsonify(get_dashboard_totals())

#Route for fetching farmers by Gender
@app.route("/get_per_district")
def get_per_district():
	#response = jsonify(get_agents_and_farmers_per_district())
	#response.headers.add('Access-Control-Allow-Origin', '*')
	return jsonify(get_agents_and_farmers_per_district())

#Route for fetching vas by Gender
@app.route("/get_va_gender")
def get_va_gender():
	return jsonify(get_vas_by_gender())

#Route for combined dashboard results
@app.route("/get_dashboard")
def get_dashboard():
	return jsonify(get_all_dashboard())

#Route for fetching all vas 
@app.route("/get_vas")
def get_vas():
	return jsonify(get_all_vas())

#Route for fetching all farmers
@app.route("/get_farmers")
def get_farmers():
	return jsonify(get_all_farmers())

#Route for fetching orders
@app.route("/get_orders")
def get_orders():
	return jsonify(get_order_totals())

#test route
@app.route("/increment_id")
def increment_id():
	return increment_bucket_id()

#test route
@app.route("/about")
def about():
  return "<h1>About Page</p>"
  
if __name__ == "__main__":
  app.run(debug==True)


from flask import Flask, render_template,jsonify, request
from flask_cors import CORS

#from test import myTasks
from fetch_dashboard_totals import get_all_dashboard
from insert_participants import save_new_va
from fetch_participants import get_all_vas,get_all_farmers
from fetch_orders import get_order_totals,get_orders_by_agents,get_farmer_orders_per_agent
from fetch_agent_details import get_va_details,get_all_va_data


app = Flask(__name__)
CORS(app)


@app.route("/")
@app.route("/home")
def home():
    return jsonify({'tasks': myTasks()})

#Route for saving farmers, vas, bcs'
#@app.route("/save_participants", methods=["POST","GET"])
#def save_participants():
	#return save_new_va()


#Route for combined dashboard results || Populating all panels on the dashboard
@app.route("/get_agents_orders")
def get_agents_orders():
	return jsonify(get_orders_by_agents())

#Route for combined dashboard results || Populating all panels on the dashboard
#@app.route("/get_dashboard")
#def get_dashboard():
	#return jsonify(get_all_dashboard())

#Route for fetching all vas || Populating table for vas
@app.route("/get_vas")
def get_vas():
	return jsonify(get_all_vas())

#Route for fetching all farmers || Populating table for farmers
@app.route("/get_farmers")
def get_farmers():
	return jsonify(get_all_farmers())

#Route for fetching orders || Populating all panels for orders
@app.route("/get_orders")
def get_orders():
	return jsonify(get_order_totals())

#Route for fetching orders || Populating all panels for orders
@app.route("/get_va_data")
def get_va_data():
	return jsonify(get_all_va_data())

#Route for fetching all farmer orders by selected agent
@app.route("/get_orders_per_agent")
def get_orders_per_agent():
	return jsonify(get_farmer_orders_per_agent())

  
if __name__ == "__main__":
  app.run(debug==True)


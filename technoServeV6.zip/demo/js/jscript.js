// Validating Empty Field
function check_empty() {
if (document.getElementById('name').value == "" || document.getElementById('email').value == "" || document.getElementById('msg').value == "") {
alert("Fill All Fields !");
} else {
document.getElementById('form').submit();
alert("Form Submitted Successfully...");
}
}
//Function To Display Popup
function div_show(id,item,qty,amount,date,notes) {
document.getElementById('abc').style.display = "block";
document.getElementById('edit_item').value=item;
document.getElementById('edit_qty').value=qty;
document.getElementById('edit_amount').value=amount;
document.getElementById('edit_date').value=date;
document.getElementById('edit_notes').value=notes;
document.getElementById('edit_id').value=id;
}

//Function To Display Calculator pop up
function div_show_calc(){
	document.getElementById('calc').style.display = "block";
}
function show_popup(){
    $('#addPopup').modal('show');
}

function invest_page(){
  document.getElementById('invest_page').onclick= function(){
    location.href="/invest."
  }
}

function showSweetAlert(material,cb){


  var selectedcb = document.getElementById(cb).checked;
  if(selectedcb==true){

  }
  else{
     swal({title:"Confirm",
    text:"DO you have any "+ material +" or you DON'T have plans of using "  +material+ "?",
    showCancelButton:true, 
    confirmButtonText:"I have my "+material, 
    confirmButtonColor:"#5cb85c",
    cancelButtonText:"I dont have plans",
    cancelButtonColor: '#d33',
    padding:50,
    width:650,
    showCloseButton:true,});
  }

 


}

    function truncate(amount){
     var result= Math.round(amount*10)/10;
      return result.toLocaleString('en');
    }


function plants_calc(){
	var acreage = document.getElementById('acre').value;//the land size
  var rentcb = document.getElementById("rentcheckbox").checked;
  var laborcb = document.getElementById("laborcheckbox").checked;
  var seed_costcb = document.getElementById("seed_sowcheckbox").checked;
  var seed_sowcb = document.getElementById("seed_sowcheckbox").checked;
  var fertilizercb = document.getElementById("fertilizercheckbox").checked;
  var sprayingcb = document.getElementById("sprayingcheckbox").checked;
  var weedingcb = document.getElementById("weedingcheckbox").checked;

  //cost of renting land per acre
  var h_rent =document.getElementById('h_rent').value;
  if(rentcb==true){
    var l_rent = h_rent * acreage;
  }
  else{
    var l_rent = 0;
  }
  document.getElementById('l_rent').innerHTML='Ush.' + truncate(h_rent * acreage);
	
  //cost of labor per acre
  var h_labor =document.getElementById('h_labor').value;
  if(laborcb==true){
    var l_labor = h_labor * acreage;
  }

  else{
    var l_labor = 0;
  }
  document.getElementById('l_labor').innerHTML='Ush.' + truncate(h_labor * acreage);

  //cost of seeds per kg on an acre
  var h_seed_cost =document.getElementById('h_seed_cost').value;
  if(seed_costcb==true){
    var l_seed_cost = h_seed_cost * acreage;
  }

  else{
    var l_seed_cost = 0;;
  }
  document.getElementById('l_seed_cost').innerHTML='Ush.' + truncate(h_seed_cost * acreage);
  

   /* //cost of seeds per kg
    var h_seed_cost =document.getElementById('h_seed_cost').value;
    var l_seed_cost = h_seed_cost * acreage;
    document.getElementById('l_seed_cost').innerHTML='Ush.' + l_seed_cost;*/

  //number of kg sowed on an acre
  var h_seed_sow =document.getElementById('h_seed_sow').value;
  if(seed_sowcb==true){
    var l_seed_sow = h_seed_sow * acreage;
  }
  else{
    var l_seed_sow =h_seed_sow * acreage * 0.9;
  }
  document.getElementById('l_seed_sow').innerHTML= truncate((h_seed_sow * acreage)) + 'Kg';

    /*//number of kg sowed
    var h_seed_sow =document.getElementById('h_seed_sow').value;
    var l_seed_sow = h_seed_sow * acreage;
    document.getElementById('l_seed_sow').innerHTML= l_seed_sow + 'Kg';*/

  //cost of fertilizers on an acre
  var h_fertilizer =document.getElementById('h_fertilizer').value;
  var fertilizer = 0;
  if(fertilizercb==true){
    var l_fertilizer = h_fertilizer * acreage;
    fertilizer = 1;
  }
  else{
    var l_fertilizer = 0; 
    fertilizer = 0.7;
  }
  document.getElementById('l_fertilizer').innerHTML='Ush.' + truncate(h_fertilizer * acreage);

   /* //cost of fertilizers
    var h_fertilizer =document.getElementById('h_fertilizer').value;
    var l_fertilizer = h_fertilizer * acreage;
    document.getElementById('l_fertilizer').innerHTML='Ush.' + l_fertilizer;*/

  //cost of spraying on an acre
  var h_spraying =document.getElementById('h_spraying').value;
  var spraying = 0;
  if(sprayingcb==true){
    var l_spraying = h_spraying * acreage;
    spraying = 1;
  }
  else{
    var l_spraying = 0;
    spraying = 0.6;
  }
  document.getElementById('l_spraying').innerHTML='Ush.' + truncate(h_spraying * acreage);
/*
    //cost of spraying
    var h_spraying =document.getElementById('h_spraying').value;
    var l_spraying = h_spraying * acreage;
    document.getElementById('l_spraying').innerHTML='Ush.' + l_spraying;*/

  //cost of weedng on an acre
  var h_weeding =document.getElementById('h_weeding').value;
  var weeding = 0;
  if(weedingcb==true){
    var l_weeding = h_weeding * acreage;
    weeding = 1;
  }
  else{
    var l_weeding = 0;
    weeding = 0.6;
  }
  document.getElementById('l_weeding').innerHTML='Ush.' + truncate(h_weeding * acreage);

    /*//cost of weedng
    var h_weeding =document.getElementById('h_weeding').value;
    var l_weeding = h_weeding * acreage;
    document.getElementById('l_weeding').innerHTML='Ush.' + l_weeding;*/



    //cost of transport
    var h_transport =document.getElementById('h_transport').value;
    var l_transport = h_transport * acreage;
    document.getElementById('l_transport').innerHTML='Ush.' + truncate(l_transport);

    //the total expenses
    var l_total =l_rent + l_labor + l_seed_cost + l_fertilizer + l_spraying + l_weeding + l_transport;
    document.getElementById('l_total').innerHTML='Ush.' + truncate(l_total);

       //number of kg harvested
    var h_seed_harvest =document.getElementById('h_seed_harvest').value;
    var l_seed_harvest =h_seed_harvest * l_seed_sow * fertilizer * spraying * weeding;
    document.getElementById('l_seed_harvest').innerHTML=truncate(l_seed_harvest) + 'Kgs';

    //the total revenue acrued
    var h_seed_price =document.getElementById('h_seed_price').value;
    var l_total_revenue =l_seed_harvest * h_seed_price;
    document.getElementById('l_total_revenue').innerHTML='Ush.' + truncate(l_total_revenue);

    //the profit made after selling off the harvest
    var l_profit =l_total_revenue - l_total;
    document.getElementById('l_profit').innerHTML='Ush.' + truncate(l_profit);

}

//poultrys_calc
function poultrys_calc(){

	var chicks = document.getElementById('chicks').value;//the land size

    document.getElementById('l_bird_number').innerHTML='Birds(' + chicks + ' birds)';
  
    //cost of incubating chicks
    var h_bird_cost =document.getElementById('h_bird_cost').value;
    var l_bird_cost = (h_bird_cost * chicks)/100;
    document.getElementById('l_bird_cost').innerHTML='Ush.' + l_bird_cost;

	//cost of incubating chicks
    var h_incubation =document.getElementById('h_incubation').value;
    var l_incubation = (h_incubation * chicks)/100;
    document.getElementById('l_incubation').innerHTML='Ush.' + l_incubation;

    //cost of immunizing
    var h_immunization =document.getElementById('h_immunization').value;
    var l_immunization = (h_immunization * chicks)/100;
    document.getElementById('l_immunization').innerHTML='Ush.' + l_immunization;

    //cost of water
    var h_water =document.getElementById('h_water').value;
    var l_water = (h_water * chicks)/100;
    document.getElementById('l_water').innerHTML='Ush.' + l_water;

    //cost of lighting
    var h_lighting =document.getElementById('h_lighting').value;
    var l_lighting = (h_lighting * chicks)/100;
    document.getElementById('l_lighting').innerHTML='Ush.' + l_lighting;

    //cost of labor
    var h_labor =document.getElementById('h_labor').value;
    var l_labor= (h_labor* chicks)/100;
    document.getElementById('l_labor').innerHTML='Ush.' + l_labor;

    //cost of feeding
    var h_feeding =document.getElementById('h_feeding').value;
    var l_feeding = (h_feeding * chicks)/100;
    document.getElementById('l_feeding').innerHTML='Ush.' + l_feeding;

    //cost of transportation
    var h_transportation =document.getElementById('h_transportation').value;
    var l_transportation = (h_transportation * chicks)/100;
    document.getElementById('l_transportation').innerHTML='Ush.' + l_transportation;

     //cost of coffee husks
    var h_husks =document.getElementById('h_husks').value;
    var l_husks = (h_husks * chicks)/100;
    document.getElementById('l_husks').innerHTML='Ush.' + l_husks;

    //the total expenses
    var l_total_exp =l_incubation + l_immunization + l_water + l_lighting + l_labor + l_feeding +
     l_transportation + l_husks + l_bird_cost;
    document.getElementById('l_total_exp').innerHTML='Ush.' + l_total_exp;


    //the total revenue acrued
    var h_bird_price =document.getElementById('h_bird_price').value;
    var l_total_revenue =chicks * h_bird_price;
    document.getElementById('l_total_revenue').innerHTML='Ush.' + l_total_revenue;

    //the profit made after selling off the harvest
    var l_profit =l_total_revenue - l_total_exp;
    document.getElementById('l_profit').innerHTML='Ush.' + l_profit;

}

//animals_calc
function show_animals(){
	var male= 0;
	var female=0;
	var female = document.getElementById('female').value;
	var male = document.getElementById('male').value;

	var animals_number = +female + +male;
	

    document.getElementById('l_animal_number').innerHTML='Calves(' + animals_number + ' calves)';
  
  //cost of labor
  var h_labor = document.getElementById('h_labor').value;
  var l_labor= h_labor*animals_number;
  document.getElementById('l_labor').innerHTML = 'Ush.'+l_labor;

  //cost of vaccination
  var h_vaccination = document.getElementById('h_vaccination').value;
  var l_vaccination= h_vaccination*animals_number;
  document.getElementById('l_vaccination').innerHTML = 'Ush.'+l_vaccination;


  //cost of animal
  var h_animal_cost = document.getElementById('h_animal_cost').value;
  var l_animal_cost= h_animal_cost*animals_number;
  document.getElementById('l_animal_cost').innerHTML = 'Ush.'+l_animal_cost;


  //cost of feeding
  var h_feeding= document.getElementById('h_feeding').value;
  var l_feeding= h_feeding*animals_number;
  document.getElementById('l_feeding').innerHTML = 'Ush.'+l_feeding;


  //cost of water
  var h_water = document.getElementById('h_water').value;
  var l_water= h_water*animals_number;
  document.getElementById('l_water').innerHTML = 'Ush.'+l_water;

  //cost of treatment
  var h_treatment = document.getElementById('h_treatment').value;
  var l_treatment= h_treatment*animals_number;
  document.getElementById('l_treatment').innerHTML = 'Ush.'+l_treatment;

  //total acrued expenses
  var l_total_exp = l_labor + l_vaccination + l_animal_cost + l_feeding + l_water + l_treatment;
  document.getElementById('l_total_exp').innerHTML = 'Ush.'+l_total_exp;

  //number of calves
  document.getElementById('l_calf_number').innerHTML = animals_number - male;

  //the total revenue
  var h_animal_price = document.getElementById('h_animal_price').value;
  var l_total_revenue = animals_number*h_animal_price;
  document.getElementById('l_total_revenue').innerHTML ='Ush.' + l_total_revenue;

  //the profit
  var l_profit = l_total_revenue - l_total_exp;
  document.getElementById('l_profit').innerHTML ='Ush.' + l_profit;
   
}

//Function to Hide Popup
function div_hide(){
document.getElementById('abc').style.display = "none";
}
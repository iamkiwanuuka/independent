

var serverURL ="http://localhost:5000/";
var ordersData;
var vaData;
var farmerData;
var dashboardData;
var reportsData;

// Calculate age from date of birth
function getAge(dob){

	// if only year is sent
	if($.isNumeric(dob)) {
		var now = new Date();
		var age =now.getFullYear() - dob;
		return age;
	}

	// if full date is sent
	if(jQuery.type(dob)==="date"){
		mydob = new Date(dob);
		var today = new Date();
		var age = Math.floor((today-mydob) / (365.25 * 24 * 60 * 60 * 1000));
		return age;
	}

	// if format sent is neither date nor number
	else{
		return '18+'
	}
}

// Saved or failed to save Feedback
function showFeedback(name,status){
	var msg="";
	if(status.toLowerCase()=="success"){msg = name+" saved successfully";}
	else{msg = "Failed to save "+name;}
	$('#feedback-div').empty().append("<p><img src='icons/saved.png' height='45px'></p>"+
    "<h4>"+msg+"</h4>");

  	$('#feedback-div').fadeIn().delay(3000).fadeOut();
}

function exportFiles(exportTo, file,tableId){
	if(file=='' || file ==null || file== undefined ){
		//if($('#export-span')){return;}
		$("#loader-div").append("<p id='export-span'>Couldn't export to "+exportTo.toUpperCase()+". No data found.</p>");
		$('#export-span').fadeIn().delay(1500).fadeOut(function(){
			$('#export-span').remove();
		});
		return;
	}
	var tableToExport = document.getElementById(tableId);
	var instance = new TableExport(tableToExport, {formats: [exportTo],exportButtons: false});
	var exportData = instance.getExportData()[tableId][exportTo];
	instance.export2file(exportData.data, exportData.mimeType, exportData.filename, exportData.fileExtension);

}
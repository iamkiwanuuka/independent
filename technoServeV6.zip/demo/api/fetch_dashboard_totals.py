
from couchbase.n1ql import N1QLQuery
from config import serverBucket
bucket = serverBucket()


def get_dashboard_totals():
    global res
    res ={}
    #query_test = N1QLQuery("SELECT COUNT(*) AS test_cnt FROM `test`")
    #for row in bucket.n1ql_query(query_test):
        #res.update(row)

    query_va = N1QLQuery("SELECT COUNT(*) AS va_cnt FROM `test` WHERE type='va' AND vaId like 'AK/DP/0006%'")
    for row in bucket.n1ql_query(query_va):
        res.update(row)

    query_farmer = N1QLQuery("SELECT COUNT(*) AS farmer_cnt FROM `test` WHERE type='farmer' AND vaId like 'AK/DP/0006%'")
    for row in bucket.n1ql_query(query_farmer):
        res.update(row)

    query_income = N1QLQuery("SELECT SUM(cost) AS income_cnt FROM `test` WHERE type='custom_income'  AND vaId like 'AK/DP/0006%'")
    for row in bucket.n1ql_query(query_income):
        res.update(row)

    query_expenses = N1QLQuery("SELECT SUM(cost) AS expense_cnt FROM `test` WHERE type='custom_expenses'  AND vaId like 'AK/DP/0006%'")
    for row in bucket.n1ql_query(query_expenses):
        res.update(row)

    query_acreage = N1QLQuery("SELECT IFMISSINGORNULL(SUM(IFMISSINGORNULL(garden_acreage_not_mapped,0)),0) AS total_acreage FROM test WHERE type='farmer' AND vaId like 'AK/DP/0006%'")
    for row in bucket.n1ql_query(query_acreage):
        res.update(row)

    query_services = N1QLQuery("SELECT count(distinct(type)) as total_services from `test` where type IN ['soil_test','planting','map_cordinates','order'] and vaId like 'AK/DP/0006%'")
    for row in bucket.n1ql_query(query_services):
        res.update(row)

    return res
    #return 1

def get_vas_by_gender():
    #global res
    res =[]
    query_va_male = N1QLQuery("SELECT COUNT(*) AS va_male_count FROM `test` WHERE type='va' AND vaId like 'AK/DP/0006%' AND (va_gender='Male' OR va_gender='male' OR va_gender='M' OR va_gender='m')")
    for row in bucket.n1ql_query(query_va_male):
        res.append(row['va_male_count'])

    query_va_female = N1QLQuery("SELECT COUNT(*) AS va_female_count FROM `test` WHERE type='va' AND vaId like 'AK/DP/0006%' AND (va_gender='Female' OR va_gender='female' OR va_gender='F' OR va_gender='f')")
    for row in bucket.n1ql_query(query_va_female):
        res.append(row['va_female_count'])

    return res

def get_farmers_by_gender():
    #global res
    res =[]
    query_va_male = N1QLQuery("SELECT COUNT(*) AS va_male_count FROM `test` WHERE type='farmer' AND vaId like 'AK/DP/0006%' AND (farmer_gender='Male' OR farmer_gender='male' OR farmer_gender='M' OR farmer_gender='m')")
    for row in bucket.n1ql_query(query_va_male):
        res.append(row['va_male_count'])

    query_va_female = N1QLQuery("SELECT COUNT(*) AS va_female_count FROM `test` WHERE type='farmer' AND vaId like 'AK/DP/0006%' AND (farmer_gender='Female' OR farmer_gender='female' OR farmer_gender='F' OR farmer_gender='f')")
    for row in bucket.n1ql_query(query_va_female):
        res.append(row['va_female_count'])

    return res

def get_agents_and_farmers_per_district_old():
    districts = ["Gulu","Lira","Amuru","Omoro","Arua"]
    va_res =[]
    farmer_res =[]
    result={}
    for distr in districts:
        query_district_vas = N1QLQuery("SELECT COUNT(*) AS distr_cnt FROM `test` WHERE type='va' AND vaId like 'AK/DP/0006%' AND va_district='%s' GROUP BY va_district" % distr)
        for row in bucket.n1ql_query(query_district_vas):
            va_res.append(row['distr_cnt'])
    for distr in districts:
        query_district_farmers = N1QLQuery("SELECT COUNT(*) AS distr_cnt FROM `test` WHERE type='farmer' AND vaId like 'AK/DP/0006%' AND farmer_district='%s' GROUP BY farmer_district" % distr)
        for row in bucket.n1ql_query(query_district_farmers):
            farmer_res.append(row['distr_cnt'])
    result['districts']=districts
    result['vas_per_district']=va_res
    result['farmers_per_district']=farmer_res

    return result

def get_agents_and_farmers_per_district():
    va_res =[]
    farmer_res =[]
    result={}
    query_district_vas = N1QLQuery("SELECT count(*) as vas_per_distr, va_district from test WHERE type='va' AND vaId like 'AK/DP/0006%' GROUP BY va_district ORDER BY va_district")
    for row in bucket.n1ql_query(query_district_vas):
        distr = row['va_district']
        if(distr=="arua" or distr=="Lira" or distr=="Amuru" or distr=="Omoro" or distr=="Gulu"):
            va_res.append(row['vas_per_distr'])
    query_district_vas = N1QLQuery("SELECT count(*) as farmers_per_distr, farmer_district from test WHERE type='farmer' AND vaId like 'AK/DP/0006%' GROUP BY farmer_district ORDER BY farmer_district")
    for row in bucket.n1ql_query(query_district_vas):
        distr = row['farmer_district']
        if(distr=="arua" or distr=="Lira" or distr=="Amuru" or distr=="Omoro" or distr=="Gulu"):
            farmer_res.append(row['farmers_per_distr'])
    result['vas_per_district']=va_res
    result['farmers_per_district']=farmer_res

    return result

def get_top_performing_vas():
    result = []
    query_performance = N1QLQuery("SELECT count(*) as cnt, vaId from test where type='order' and vaId like 'AK/DP/0006%' group by vaId order by cnt desc LIMIT 6")
    for row in bucket.n1ql_query(query_performance):
        va_id = row['vaId']
        res={}
        query_name = N1QLQuery("SELECT va_name FROM `test` WHERE type='va' AND vaId='%s'" % va_id)
        for name in bucket.n1ql_query(query_name):
            res['va_name']=name['va_name']
        res['cnt']=row['cnt']
        result.append(res)

    return result

def get_va_services_per_district_per_month():
    districts = ["Amuru","Arua","Gulu","Lira","Omoro","Other"]
    #months = ['1','2','3','4','5','6','7','8','9','10','11','12']
    months = [1,2,3,4,5,6,7,8,9,10,11,12]
    short_months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
    full_results = []
    #query_update_district = N1QLQuery("UPDATE `test` a SET a.va_district = FIRST v.va_district FOR v IN (SELECT b.va_district,meta(b).id,b.vaId from `test` b WHERE b.type='va' AND b.vaId like 'AK/DP/0006%') WHEN v.vaId = a.vaId END WHERE a.type='order'")
    query_month_services = N1QLQuery("SELECT DATE_PART_STR(details.time,'month') AS mth, count(*) AS cnt, IFMISSINGORNULL(a.va_district,'Other') as va_district FROM `test` a WHERE a.type='order' AND a.vaId like 'AK/DP/0006%' GROUP BY DATE_PART_STR(details.time,'month'), a.va_district")
    result={}
    #Fetch full list grouped by district, month and the corresponding number
    for row in bucket.n1ql_query(query_month_services):
        full_results.append(row)

    #Nested Loops
    for district in districts:
        number_res =[]
        for month in months:
            #Search method
            num = next((full_result['cnt'] for full_result in full_results if (full_result["va_district"].lower() == ''+district.lower() and full_result["mth"]== month)),0)
            number_res.append(num)
        result[''+district]=number_res
    result['districts']=districts
    result['months']=short_months
    return result


def get_all_dashboard():
    result = {}
    result['dashboard_totals']=get_dashboard_totals()
    result['va_genders']=get_vas_by_gender()
    result['farmer_genders']=get_farmers_by_gender()
    result['agents_and_farmers_per_district']=get_agents_and_farmers_per_district()
    result['top_performing_vas']=get_top_performing_vas()
    result['va_services_per_district_per_month']=get_va_services_per_district_per_month()
    return result

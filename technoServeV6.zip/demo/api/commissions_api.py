from couchbase.n1ql import N1QLQuery
from config import serverBucket
bucket = serverBucket()
#farmer_bucket = Bucket('couchbase://localhost/farmer-bucket')


def add_agent_commissions():
    return 0

def get_agent_commissions():
    return 0


from couchbase.n1ql import N1QLQuery
from config import serverBucket
bucket = serverBucket()
#farmer_bucket = Bucket('couchbase://localhost/farmer-bucket')


# def get_value_chain_distribution():
#     value_chains = ["Gulu","Lira","Amuru","Omoro","Arua"]
#     va_res =[]
#     farmer_res =[]
#     result={}
#     for value_chain in value_chains:
#         query_district_vas = N1QLQuery("SELECT COUNT(*) AS distr_cnt FROM `va-bucket` WHERE type='va' AND va_district='%s' GROUP BY va_district" % distr)
#         for row in bucket.n1ql_query(query_district_vas):
#             va_res.append(row['distr_cnt'])
#     for value_chain in value_chains:
#         query_district_farmers = N1QLQuery("SELECT COUNT(*) AS distr_cnt FROM `va-bucket` WHERE type='farmer' AND farmer_district='%s' GROUP BY farmer_district" % distr)
#         for row in bucket.n1ql_query(query_district_farmers):
#             farmer_res.append(row['distr_cnt'])
#     result['value_chains']=value_chains
#     result['vas_distribution']=va_res
#     result['farmers_distribution']=farmer_res

#     return result

#Agent Training not completed
def get_agent_training_distribution():
    return 0

#Value chain is na for farmers and vas | Not clear
#Is value chain defined as participant is registered or is it to be picked from orders
def get_value_chain_distribution():
    value_chain_res =[]
    va_number_res =[]
    farmer_number_res =[]
    result = {}
    query_qty = N1QLQuery("SELECT value_chain, COUNT(value_chain) as num, type FROM `test` WHERE (type='farmer' OR type ='va') AND value_chain GROUP BY value_chain, type")
    for row in bucket.n1ql_query(query_qty):
        value_chain_res.append(row['value_chain'])
        if row['type']=='va':
            va_number_res.append(row['num'])
        if row['type']=='farmer':
            farmer_number_res.append(row['num'])
    result['value_chain']=value_chain_res
    result['va_number']=va_number_res
    result['farmer_number']=farmer_number_res
    return result

def get_services_uptaken_by_farmers():
    services_res =[]
    number_res =[]
    result = {}
    query_qty = N1QLQuery("SELECT `order`.category as services, COUNT(`order`.category) as num FROM `test` a UNNEST `order` WHERE a.type='order' AND `order`.category GROUP BY `order`.category")
    for row in bucket.n1ql_query(query_qty):
        services_res.append(row['services'])
        number_res.append(row['num'])
    result['services']=services_res
    result['number']=number_res
    return result

def get_qty_bulked_by_agents():
    distr_res =[]
    qty_res =[]
    result = {}
    query_qty = N1QLQuery("SELECT IFMISSINGORNULL(a.va_district,'Other') as distr, SUM(`order`.qty) as district_qty FROM `test` a UNNEST `order` WHERE a.type='order' GROUP BY a.va_district")
    for row in bucket.n1ql_query(query_qty):
        distr_res.append(row['distr'])
        qty_res.append(row['district_qty'])
    result['districts']=distr_res
    result['qty']=qty_res
    return result

#Commission is calculated at 5%
#Please define clearly the formula for calculating commission. We are doing double work on this 
def get_agent_produce_commission():
    distr_res =[]
    commission_res =[]
    result = {}
    query_qty = N1QLQuery("SELECT IFMISSINGORNULL(a.va_district,'Other') as distr, SUM(a.total)*0.05 as district_ttl FROM `test` a WHERE a.type='order' GROUP BY a.va_district")
    for row in bucket.n1ql_query(query_qty):
        distr_res.append(row['distr'])
        commission_res.append(row['district_ttl'])
    result['districts']=distr_res
    result['commission']=commission_res
    return result

def get_agent_input_sales_per_district():
    return 0
    # inputs_res =[]
    # number_res =[]
    # result = {}
    # query_qty = N1QLQuery("SELECT `order`.category as inputs, COUNT(`order`.category) as num, a.va_district FROM `va-bucket` a UNNEST `order` WHERE a.type='order' AND `order`.category IN ['Fertilizers','Seeds','Pesticides','Herbicides'] GROUP BY `order`.category")
    # for row in bucket.n1ql_query(query_qty):
    #     inputs_res.append(row['inputs'])
    #     number_res.append(row['num'])
    # result['inputs']=inputs_res
    # result['number']=number_res
    # return result
    
#What are other services. How are they identified under the orders thingy
def get_revenue_from_other_services():
    # other_services_res =[]
    # number_res =[]
    # result = {}
    # query_qty = N1QLQuery("SELECT `order`.category as other_services_res, COUNT(`order`.category) as num, a.va_district FROM `va-bucket` a UNNEST `order` WHERE a.type='order' AND `order`.category IN ['Fertilizers','Seeds','Pesticides','Herbicides'] GROUP BY `order`.category")
    # for row in bucket.n1ql_query(query_qty):
    #     inputs_res.append(row['inputs'])
    #     number_res.append(row['num'])
    # result['inputs']=inputs_res
    # result['number']=number_res
    # return result
    return 0

def get_all_reports():
    result = {}
    result['agent_training_distribution']=get_agent_training_distribution()
    result['value_chain_distribution']=get_value_chain_distribution()
    result['services_uptaken_by_farmers']=get_services_uptaken_by_farmers()
    result['qty_bulked_by_agents']=get_qty_bulked_by_agents()
    result['agent_produce_commission']=get_agent_produce_commission()
    result['agent_input_sales_per_district']=get_agent_input_sales_per_district()
    result['revenue_from_other_services']=get_revenue_from_other_services()
    return result


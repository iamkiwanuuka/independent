from couchbase.n1ql import N1QLQuery
from config import serverBucket
bucket = serverBucket()
#farmer_bucket = Bucket('couchbase://localhost/farmer-bucket')


# def get_value_chain_distribution():
#     value_chains = ["Gulu","Lira","Amuru","Omoro","Arua"]
#     va_res =[]
#     farmer_res =[]
#     result={}
#     for value_chain in value_chains:
#         query_district_vas = N1QLQuery("SELECT COUNT(*) AS distr_cnt FROM `va-bucket` WHERE type='va' AND va_district='%s' GROUP BY va_district" % distr)
#         for row in bucket.n1ql_query(query_district_vas):
#             va_res.append(row['distr_cnt'])
#     for value_chain in value_chains:
#         query_district_farmers = N1QLQuery("SELECT COUNT(*) AS distr_cnt FROM `va-bucket` WHERE type='farmer' AND farmer_district='%s' GROUP BY farmer_district" % distr)
#         for row in bucket.n1ql_query(query_district_farmers):
#             farmer_res.append(row['distr_cnt'])
#     result['value_chains']=value_chains
#     result['vas_distribution']=va_res
#     result['farmers_distribution']=farmer_res

#     return result

#Agent Training not completed
def get_agent_training_distribution():
    return 0

###
def get_value_chain_distribution():
    value_chain_res =[]
    va_number_res =[]
    farmer_number_res =[]
    result = {}
    #query_update_district = N1QLQuery("UPDATE `test` a SET a.va_district = FIRST v.va_district FOR v IN (SELECT b.va_district,meta(b).id,b.vaId from `test` b WHERE b.type='va' AND b.vaId like 'AK/DP/0006%') WHEN v.vaId = a.vaId END WHERE a.type='order'")
    query_qty = N1QLQuery("SELECT IFMISSINGORNULL(a.value_chain,'Other') as value_chain, COUNT(a.value_chain) as num, a.type FROM `test` a WHERE a.type IN ['farmer','va'] AND (a.vaId LIKE 'AK/DP/0006%') GROUP BY a.value_chain, a.type")
    for row in bucket.n1ql_query(query_qty):
        v_chain = row['value_chain']
        if v_chain == 'NA':
            v_chain = 'UnSpecified'
        value_chain_res.append(v_chain)
        if row['type']=='va':
            va_number_res.append(row['num'])
        if row['type']=='farmer':
            farmer_number_res.append(row['num'])
    result['value_chain']=value_chain_res
    result['va_number']=va_number_res
    result['farmer_number']=farmer_number_res
    return result

###
def get_services_uptaken_by_farmers():
    services_res =[]
    number_res =[]
    result = {}
    #query_qty = N1QLQuery("SELECT `order`.category as services, COUNT(`order`.category) as num FROM `test` a UNNEST `order` WHERE a.type='order' AND `order`.category AND a.vaId LIKE 'AK/DP/0006%' GROUP BY `order`.category")
    query_qty = N1QLQuery("SELECT a.type as services, COUNT(a.type) as num FROM `test` a WHERE a.type IN ['soil_test','planting','map_cordinates','order'] AND a.vaId LIKE 'AK/DP/0006%' GROUP BY a.type")
    for row in bucket.n1ql_query(query_qty):
        service = row['services']
        if service == 'order':
            service = 'Inputs'
        if service == 'soil_test':
            service = 'Soil Testing'
        if service == 'map_cordinates':
            service = 'Geo Mapping'
        if service == 'planting':
            service = 'Planting'
        services_res.append(service)
        number_res.append(row['num'])
    result['services']=services_res
    result['number']=number_res
    return result

###
def get_qty_bulked_by_agents():
    distr_res =[]
    qty_res =[]
    result = {}
    query_qty = N1QLQuery("SELECT IFMISSINGORNULL(a.va_district,'Other') as distr, SUM(`order`.qty) as district_qty FROM `test` a UNNEST `order` WHERE a.type='order' AND a.vaId LIKE 'AK/DP/0006%' GROUP BY a.va_district")
    for row in bucket.n1ql_query(query_qty):
        distr_res.append(row['distr'])
        qty_res.append(row['district_qty'])
    result['districts']=distr_res
    result['qty']=qty_res
    return result

#Commission is calculated at 5% 
def get_agent_produce_commission():
    distr_res =[]
    commission_res =[]
    result = {}
    query_qty = N1QLQuery("SELECT IFMISSINGORNULL(a.va_district,'Other') as distr, SUM(a.total)*0.05 as district_ttl FROM `test` a WHERE a.type='order' AND a.vaId LIKE 'AK/DP/0006%' GROUP BY a.va_district")
    for row in bucket.n1ql_query(query_qty):
        distr_res.append(row['distr'])
        commission_res.append(row['district_ttl'])
    result['districts']=distr_res
    result['commission']=commission_res
    return result

###
def get_agent_input_sales_per_district():
    result = {}
    full_results = []
    districts = ["Amuru","Arua","Gulu","Lira","Omoro"]
    farm_inputs = ["Fertilizers","Seeds","Herbicides","Pesticides","Farming Tools"]
    query_qty = N1QLQuery("SELECT count(b.category) as num, b.category, a.va_district from `test` a UNNEST `order` b where a.type='order' and a.va_district and a.vaId like 'AK/DP/0006%' GROUP BY b.category,a.va_district")
    
    #Fetch full list grouped by district, category and the corresponding number
    for row in bucket.n1ql_query(query_qty):
        full_results.append(row)

    #Nested Loops | Loop through farm inputs and districts to avoid data mismatches
    for farm_input in farm_inputs:
        number_res =[]
        for district in districts:
            #Dont try to understand this line, you will quit code guys. Hahahahaha
            num = next((full_result['num'] for full_result in full_results if (full_result["va_district"].lower() == ''+district.lower() and full_result["category"].lower() == ''+farm_input.lower())),0)
            number_res.append(num)
        result[''+farm_input]=number_res
    result['districts']=districts
    result['farm_inputs']=farm_inputs
    return result
    
#Commission not yet set
#Other services excluding input sales (type='order')
def get_revenue_from_other_services():
    result = {}
    full_results = []
    districts = ["Amuru","Arua","Gulu","Lira","Omoro"]
    #farm_services = ["Soil Testing","Digital Profiling","Geo Mapping"]
    farm_services = ['soil_test','planting','map_cordinates']
    query_qty = N1QLQuery("SELECT a.type as service, COUNT(a.type) as num, IFMISSINGORNULL(a.va_district,'Other') as va_district FROM `test` a WHERE a.type IN ['soil_test','planting','map_cordinates'] AND a.vaId LIKE 'AK/DP/0006%' GROUP BY a.type,a.va_district")
    
    #Fetch full list grouped by district, service and the corresponding number
    for row in bucket.n1ql_query(query_qty):
        full_results.append(row)

    #Nested Loops | Loop through farm inputs and districts to avoid data mismatches
    for farm_service in farm_services:
        number_res =[]
        for district in districts:
            #Okay now you can try to understand it. Hahahahaha
            num = next((full_result['num'] for full_result in full_results if (full_result["va_district"].lower() == ''+district.lower() and full_result["service"].lower() == ''+farm_service.lower())),0)
            number_res.append(num)
        result[''+farm_service]=number_res
    result['districts']=districts
    result['farm_services']=farm_services
    return result

def get_all_reports():
    result = {}
    result['agent_training_distribution']=get_agent_training_distribution()
    result['value_chain_distribution']=get_value_chain_distribution()
    result['services_uptaken_by_farmers']=get_services_uptaken_by_farmers()
    result['qty_bulked_by_agents']=get_qty_bulked_by_agents()
    result['agent_produce_commission']=get_agent_produce_commission()
    result['agent_input_sales_per_district']=get_agent_input_sales_per_district()
    result['revenue_from_other_services']=get_revenue_from_other_services()
    return result


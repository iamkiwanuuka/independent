from couchbase.n1ql import N1QLQuery
from config import serverBucket
bucket = serverBucket()
#farmer_bucket = Bucket('couchbase://localhost/farmer-bucket')


def get_value_chain_distribution():
    value_chains = ["Gulu","Lira","Amuru","Omoro","Arua"]
    va_res =[]
    farmer_res =[]
    result={}
    for value_chain in value_chains:
        query_district_vas = N1QLQuery("SELECT COUNT(*) AS distr_cnt FROM `va-bucket` WHERE type='va' AND va_district='%s' GROUP BY va_district" % distr)
        for row in bucket.n1ql_query(query_district_vas):
            va_res.append(row['distr_cnt'])
    for value_chain in value_chains:
        query_district_farmers = N1QLQuery("SELECT COUNT(*) AS distr_cnt FROM `va-bucket` WHERE type='farmer' AND farmer_district='%s' GROUP BY farmer_district" % distr)
        for row in bucket.n1ql_query(query_district_farmers):
            farmer_res.append(row['distr_cnt'])
    result['value_chains']=value_chains
    result['vas_distribution']=va_res
    result['farmers_distribution']=farmer_res

    return result

def get_training_distribution():
    return 0

def get_services_uptaken_by_farmers():
    return 0

def get_produce_bulked_per_district():
    return 0

def get_agent_produce_commission_per_district():
    return 0

def get_agent_input_sales_per_district():
    return 0

def get_revenue_earned_from_other_services_per_district():
    return 0


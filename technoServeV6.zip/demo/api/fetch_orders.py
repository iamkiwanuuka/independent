from couchbase.n1ql import N1QLQuery
from config import serverBucket
bucket = serverBucket()
bucket2 = serverBucket()
#farmer_bucket = Bucket('couchbase://localhost/farmer-bucket')


def get_order_totals():
    districts = {"Gulu","Lira","Amuru","Omoro","Arua"}
    res ={}
    total_orders = 0
    for distr in districts:
        query_district_orders = N1QLQuery("SELECT COUNT(*) AS distr_cnt FROM `va-bucket` WHERE type='order' AND district='%s' GROUP BY district" % distr)
        for row in bucket.n1ql_query(query_district_orders):
            res[distr]=row['distr_cnt']
            total_orders+=int(row['distr_cnt'])
    res['Total']=total_orders
    return res
    #return 1

def get_orders_by_agents():
    res =[]
    query_va = N1QLQuery("SELECT vaId, count(*) as num_of_orders, min(details.time) as fdate, max(details.time) as ldate  FROM `test` WHERE type='order' AND vaId like 'AK/DP/0006%' GROUP BY vaId")
    for row in bucket.n1ql_query(query_va):
        #res.append(row)
        result={}
        va_id = row['vaId']
        query_det = N1QLQuery("SELECT vaId,va_name,va_district,va_gender,va_phonenumber,va_dob FROM `test` WHERE type='va' AND vaId='%s'" % va_id)
        for det in bucket.n1ql_query(query_det):
            #_res = det['test']
            result['va_name']=det['va_name']
            result['va_district']=det['va_district']
            result['va_gender']=det['va_gender']
            result['va_phonenumber']=det['va_phonenumber']
            result['va_dob']=det['va_dob']
            #result['va_district']=row
        result['vaId']=row['vaId']
        result['num_of_orders']=row['num_of_orders']
        result['fdate']=row['fdate']
        result['ldate']=row['ldate']
        res.append(result)


    return res

def get_farmer_orders_per_agent(agent_id):
    vaId = agent_id
    res =[]
    query_va = N1QLQuery("SELECT * FROM `test` WHERE type='order' AND vaId ='%s'" %vaId)
    for row in bucket.n1ql_query(query_va):
        res.append(row['test'])
    return res


from flask import Flask, render_template,jsonify, request
from flask_cors import CORS

#from test import myTasks
from fetch_dashboard_totals import get_all_dashboard
from insert_participants import save_new_va,save_new_farmer,save_new_training
from fetch_participants import get_all_vas,get_all_farmers
from fetch_orders import get_order_totals,get_orders_by_agents,get_farmer_orders_per_agent
from fetch_agent_details import get_va_details,get_all_va_data
import json


app = Flask(__name__)
CORS(app)


@app.route("/")
@app.route("/home")
def home():
    return jsonify({'tasks': myTasks()})

#Route for saving vas
@app.route("/save_va_participants", methods=['GET'])
def save_va_participants():
	agent_details = {}
	agent_details['va_name']=request.args.get('va_name')
	agent_details['va_contact']=request.args.get('va_contact')
	agent_details['va_gender']=request.args.get('va_gender')
	agent_details['va_district']=request.args.get('va_district')
	agent_details['va_subcounty']=request.args.get('va_subcounty')
	agent_details['va_parish']=request.args.get('va_parish')
	agent_details['va_village']=request.args.get('va_village')
	agent_details['va_inputs']=request.args.get('va_inputs')
	agent_details['type']='va'
	agent_details['partner_id']='AK/DP/0006'
	agent_details['va_id']='AK/DP/0006/00099'
	agent_details['va_region']='North'
	agent_details['va_country']='Uganda'
	agent_details['flag']='test'
	return jsonify(save_new_va(data_doc=agent_details))

#Route for saving vas
@app.route("/save_farmer_participants", methods=['GET'])
def save_farmer_participants():
	farmer_details = {}
	farmer_details['farmer_name']=request.args.get('farmer_name')
	farmer_details['farmer_contact']=request.args.get('farmer_contact')
	farmer_details['farmer_gender']=request.args.get('farmer_gender')
	farmer_details['farmer_district']=request.args.get('farmer_district')
	farmer_details['farmer_subcounty']=request.args.get('farmer_subcounty')
	farmer_details['farmer_parish']=request.args.get('farmer_parish')
	farmer_details['farmer_village']=request.args.get('farmer_village')
	farmer_details['farmer_inputs']=request.args.get('farmer_inputs')
	farmer_details['type']='farmer'
	farmer_details['partner_id']='AK/DP/0006'
	farmer_details['va_id']='AK/DP/0006/00099'
	farmer_details['farmer_id']='AFAYOMAR782256466LIRTELXXX'
	farmer_details['farmer_region']='North'
	farmer_details['farmer_country']='Uganda'
	farmer_details['flag']='test'
	return jsonify(save_new_farmer(data_doc=farmer_details))

#Route for saving vas
@app.route("/save_training", methods=['GET'])
def save_training():
	training_details = {}
	training_details['training_name'] = request.args.get('training_name')
	training_details['training_start_date'] = request.args.get('training_start_date')
	training_details['training_end_date'] = request.args.get('training_end_date')
	training_details['trainer_name'] = request.args.get('trainer_name')
	training_details['trainer_contact'] = request.args.get('trainer_contact')
	training_details['trainer_gender'] = request.args.get('trainer_gender')
	training_details['trainer_district'] = request.args.get('trainer_district')
	training_details['trainer_subcounty'] = request.args.get('trainer_subcounty')
	training_details['trainer_parish'] = request.args.get('trainer_parish')
	training_details['trainer_village'] = request.args.get('trainer_village')
	training_details['type']='training'
	training_details['partner_id']='AK/DP/0006'
	training_details['flag']='test'
	return jsonify(save_new_training(data_doc=training_details))



#Route for combined dashboard results || Populating all panels on the dashboard
@app.route("/get_agents_orders")
def get_agents_orders():
	return jsonify(get_orders_by_agents())

#Route for combined dashboard results || Populating all panels on the dashboard
@app.route("/get_dashboard")
def get_dashboard():
	return jsonify(get_all_dashboard())

#Route for fetching all vas || Populating table for vas
@app.route("/get_vas")
def get_vas():
	return jsonify(get_all_vas())

#Route for fetching all farmers || Populating table for farmers
@app.route("/get_farmers")
def get_farmers():
	return jsonify(get_all_farmers())

#Route for fetching orders || Populating all panels for orders
@app.route("/get_orders")
def get_orders():
	return jsonify(get_order_totals())

#Route for fetching single va and details of the va || Populating all panels for single va
@app.route("/get_va_data")
def get_va_data():
	agent_id = request.args.get('agent_id')
	return jsonify(get_all_va_data(agent_id=agent_id))

#Route for fetching all farmer orders by selected agent
@app.route("/get_orders_per_agent", methods=["GET"])
def get_orders_per_agent():
	agent_id = request.args.get('agent_id')
	return jsonify(get_farmer_orders_per_agent(agent_id=agent_id))


if __name__ == "__main__":
  app.run(debug==True)


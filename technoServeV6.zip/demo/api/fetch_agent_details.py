from couchbase.n1ql import N1QLQuery
from config import serverBucket
bucket = serverBucket()

#SELECT vaId, count(type) from `va-bucket` WHERE type='farmer' GROUP BY vaId;
def get_va_details(agent_id):
    #global res
    res ={}
    vaId = agent_id
    query_va = N1QLQuery("SELECT * FROM `test` WHERE type='va' AND vaId='%s' LIMIT 1" %vaId)
    for row in bucket.n1ql_query(query_va):
        res.update(row['test'])
    return res

def get_farmers_profiled_by_va(agent_id):
    res =[]
    vaId = agent_id
    query_va = N1QLQuery("SELECT * FROM `test` WHERE type='farmer' AND vaId='%s'" %vaId)
    for row in bucket.n1ql_query(query_va):
        res.append(row['test'])
    return res

def get_breakdown_of_inputs():
    return 0

def get_agent_commission_earned():
    return 0

def get_all_va_data(agent_id):
    result={}
    result['va_details']=get_va_details(agent_id=agent_id)
    result['farmers_profiled_by_va']=get_farmers_profiled_by_va(agent_id=agent_id)
    return result


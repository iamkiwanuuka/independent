
#import couchdb
#couch = couchdb.Server("http://Administrator:akorion1803@159.65.195.115:8091/")
#db = couch["test"]
#db = couch.create('hello_db')
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.n1ql import N1QLQuery
from couchbase.bucket import Bucket
cluster = Cluster('couchbase://159.65.195.115:8091/')
authenticator = PasswordAuthenticator('Administrator', 'akorion1803')
cluster.authenticate(authenticator)
bucket = cluster.open_bucket('test')
#bucket = Bucket(lockmode=LOCKMODE_WAIT)

va_bucket = Bucket('couchbase://localhost/va-bucket')


def serverBucket():
    return bucket

def localBucket():
    return va_bucket

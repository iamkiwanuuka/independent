<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>tecnoServe</title>
    <!--app page links-->
<link rel="stylesheet" href="/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/bootstrap.css" id="color-switcher-link">
    <link rel="stylesheet" href="/css/bootstrap-grid.css">
    <link rel="stylesheet" href="/css/fonts.css">
    <link rel="stylesheet" href="/css/bootstrap-grid.min.css">
    <link rel="stylesheet" href="/css/font-awesome.min.css">
    <link rel="stylesheet" href="/css/font-awesome.css">
  <!--sidebar page links--> 
    <!-- Material Design Icons--> 
<link href="/images/icon" rel="stylesheet">

  <!--<link type="text/css" href="css/simplebar.css" rel="stylesheet">-->

<!-- Highlight.js -->
<link type="text/css" href="/css/github-gist.css" rel="stylesheet">

<!-- App CSS (includes Bootstrap & Bootstrap Layout) -->
<link type="text/css" href="/css/app.min.css" rel="stylesheet">

<!--pop-up css-->
<link href="/css/pop_up.css" rel="stylesheet">


<!--sweetalert css-->
<link href="/css/sweetalert2.css" rel="stylesheet">





    <style>
        body {
            font-family: 'calibri';
        }

        .fa-btn {
            margin-right: 6px;
        }
        
    </style>
</head>
<body id="app-layout">
    <nav class="navbar navbar-default navbar-static-top">
        <div class="container">
            <div class="navbar-header"> 

                <!-- Branding Image -->
                <a class="navbar-brand" href="{{ url('/home') }}">
                    <img src="/images/logo2.png" height="90%">
                </a>
            </div>

            <div class="collapse navbar-collapse" id="app-navbar-collapse">
                <!-- Left Side Of Navbar -->
                <ul class="nav navbar-nav">
                    <li><a href="{{ url('/home') }}" style="color: #007236;">tecnoServe</a></li>
                </ul>

                <!-- Right Side Of Navbar -->
                <ul class="nav navbar-nav navbar-right">
                    <!-- Authentication Links -->
                    @if (Auth::guest())
                        <li><a href="{{ url('/login') }}">Login</a></li>
                        <li><a href="{{ url('/register') }}">Register</a></li>
                    @else
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                {{ Auth::user()->name }} 
                            </a>

                            <ul class="dropdown-menu" role="menu">
                                <li><a href="{{ url('/logout') }}"><i class="fa fa-btn fa-sign-out"></i>Logout</a></li>
                            </ul>
                        </li>
                    @endif
                </ul>
            </div>
        </div>
    </nav>


@yield('content')
@yield('agents')
<footer style="background-color: green"></footer>
<!--Pop up js-->
<script src="/js/jscript.js"></script>

<!--sidebar js-->
<script src="/js/jquery-2.2.3.min.js"></script>
<script src="/js/bootstrap.min.js"></script>
<script src="/js/modernizr-2.6.2.min.js"></script>
<script src="/js/owl.carousel.js"></script>

<script src="/js/sweetalert2.js"></script>

<!--  <script src="js/app.browserify.min.js"></script>
<script src="js/jquery-2.2.3.js"></script>

<script src="js/bootstrap.js"></script>-->


</body>
</html>

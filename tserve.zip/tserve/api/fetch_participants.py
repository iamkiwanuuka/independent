from couchbase.bucket import Bucket
from couchbase.n1ql import N1QLQuery
va_bucket = Bucket('couchbase://localhost/va-bucket')

#SELECT vaId, count(type) from `va-bucket` WHERE type='farmer' GROUP BY vaId;
def get_all_vas():
    #global res
    res =[]
    query_va = N1QLQuery("SELECT * FROM `va-bucket` WHERE type='va'")
    for row in va_bucket.n1ql_query(query_va):
        res.append(row['va-bucket'])
    return res

def get_all_farmers():
    #global res
    res =[]
    query_va = N1QLQuery("SELECT * FROM `va-bucket` WHERE type='farmer'")
    for row in va_bucket.n1ql_query(query_va):
        res.append(row['va-bucket'])
    return res
from couchbase.bucket import Bucket
from couchbase.n1ql import N1QLQuery
bucket = Bucket('couchbase://localhost/va-bucket')
#farmer_bucket = Bucket('couchbase://localhost/farmer-bucket')


def add_new_training():
    return 0

def get_training_list():
    return 0



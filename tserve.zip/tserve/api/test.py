'''from couchbase.bucket import Bucket
from couchbase.n1ql import N1QLQuery
test_bucket = Bucket('couchbase://Administrator:akorion1803@159.65.195.115/test')

def get_three_vas():
    #global res
    res =[]
    query_test = N1QLQuery("SELECT * FROM `test` WHERE type='farmer' LIMIT 2")
    for row in va_bucket.n1ql_query(query_test):
        res.append(row)
    return res'''

#import couchdb
#couch = couchdb.Server("http://Administrator:akorion1803@159.65.195.115:8091/")
#db = couch["test"]
#db = couch.create('hello_db')
from couchbase.cluster import Cluster
from couchbase.cluster import PasswordAuthenticator
from couchbase.n1ql import N1QLQuery
cluster = Cluster('couchbase://159.65.195.115:8091/')
authenticator = PasswordAuthenticator('Administrator', 'akorion1803')
cluster.authenticate(authenticator)
bucket = cluster.open_bucket('test')

tasks = [
    {
        'id': 1,
        'title': u'Buy groceries',
        'description': u'Milk, Cheese, Pizza, Fruit, Tylenol', 
        'done': False
    },
    {
        'id': 2,
        'title': u'Learn Python',
        'description': u'Need to find a good Python tutorial on the web', 
        'done': False
    }
]

def myTasks():
    res=[]
    query_va_female = N1QLQuery("SELECT COUNT(*) AS va_female_count FROM `test` WHERE type='va' AND partner_id='AK/DP/006' AND va_gender='Female' OR va_gender='female' OR va_gender='F' OR va_gender='f'")
    for row in bucket.n1ql_query(query_va_female):
        res.append(row['va_female_count'])

    return res

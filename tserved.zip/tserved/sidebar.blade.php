<!-- Sidebar -->
  <div class="sidebar sidebar-left sidebar-visible-md-up sidebar-size-3 sidebar-dark bg-primary sidebar-visible" style="margin-top: 58px;" id="sidebar" data-scrollable="">

    <!-- Brand -->
    <a href="#" class="sidebar-brand sidebar-brand-bg sidebar-brand-border">DashBoard</a>


    <!--<ul class="sidebar-menu sm-active-button-bg sm-bordered">
      <li class="sidebar-menu-item">
        <a class="sidebar-menu-button" href="#">smartAgric</a>
      </li>
    </ul>-->

    <div class="sidebar-heading ">Featured</div><hr>
    <ul class="sidebar-menu sm-active-button-bg">

      <li class="sidebar-menu-item">
        <a href="#" class="sidebar-menu-button" data-toggle="dropdown">Animals</a>
        <ul class="sidebar-submenu sm-condensed">
        @foreach ($animals as $animal)
          <li class="sidebar-menu-item">
            <a href="{{url('/animals/'.$animal->id)}}" class="sidebar-menu-button">{{$animal->name}}</a>
          </li>
         @endforeach
        </ul> 
      </li>

      <li class="sidebar-menu-item">
        <a href="#" class="sidebar-menu-button" data-toggle="dropdown">Plants</a>
        <ul class="sidebar-submenu sm-condensed">
          @foreach ($plants as $plant)
          <li class="sidebar-menu-item">
            <a href="{{url('/plants/'.$plant->id)}}" class="sidebar-menu-button">{{$plant->name}}</a>
          </li>
         @endforeach
        </ul>
      </li>

      <li class="sidebar-menu-item">
        <a href="#" class="sidebar-menu-button" data-toggle="dropdown">Poultry</a>
        <ul class="sidebar-submenu sm-condensed">
          @foreach ($poultry_types as $poultry_type)
          <li class="sidebar-menu-item">
            <a href="{{url('/poultrys/'.$poultry_type->id)}}" class="sidebar-menu-button">{{$poultry_type->types}}</a>
          </li>
         @endforeach
        </ul>
      </li>

    </ul>

    <div class="sidebar-heading">Others</div><hr/>

     <ul class="sidebar-menu sm-active-button-bg">
      <li class="sidebar-menu-item">
        <a href="#" class="sidebar-menu-button" data-toggle="dropdown">My Farm</a>
        <ul class="sidebar-submenu sm-condensed">
            <li class="sidebar-menu-item">
            <a href="{{ url('/fetchrecords/i')}}" class="sidebar-menu-button">Income</a>
           </li>
          <li class="sidebar-menu-item">
            <a href="{{ url('/fetchrecords/e')}}" class="sidebar-menu-button">Expenditure</a>
          </li>
          <li class="sidebar-menu-item">
            <a href="#" class="sidebar-menu-button">Activities</a>
          </li>
        </ul>
      </li>

        <li class="sidebar-menu-item">
        <a href="#" class="sidebar-menu-button">Account Settings</a>
      </li>

    </ul>

    <div class="sidebar-block sidebar-b-b sidebar-p-b">
      <a target="_blank" href="#" class="btn btn-block bg-white">Join a Group</a>
    </div>

    
    <p class="sidebar-p-b">Agriculture made simpler and more organized. <br></p>
    <p style="font-size: 10">&copy Copyright <?php $current_year=date("o");
    echo "$current_year";?>. All Rights reserved</p>
    
  </div>
  <!-- // END Sidebar -->



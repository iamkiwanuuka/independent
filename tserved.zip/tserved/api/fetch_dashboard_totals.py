
from couchbase.n1ql import N1QLQuery
from config import localBucket
bucket = localBucket()


def get_dashboard_totals():
    global res
    res ={}
    query_test = N1QLQuery("SELECT COUNT(*) AS test_cnt FROM `test-sample`")
    for row in bucket.n1ql_query(query_test):
        res.update(row)

    query_va = N1QLQuery("SELECT COUNT(*) AS va_cnt FROM `va-bucket` WHERE type='va'")
    for row in bucket.n1ql_query(query_va):
        res.update(row)

    query_farmer = N1QLQuery("SELECT COUNT(*) AS farmer_cnt FROM `va-bucket` WHERE type='farmer'")
    for row in bucket.n1ql_query(query_farmer):
        res.update(row)

    query_income = N1QLQuery("SELECT SUM(cost) AS income_cnt FROM `va-bucket` WHERE type='custom_income'")
    for row in bucket.n1ql_query(query_income):
        res.update(row)

    query_expenses = N1QLQuery("SELECT SUM(cost) AS expense_cnt FROM `va-bucket` WHERE type='custom_expenses'")
    for row in bucket.n1ql_query(query_expenses):
        res.update(row)

    return res
    #return 1

def get_vas_by_gender():
    #global res
    res =[]
    query_va_male = N1QLQuery("SELECT COUNT(*) AS va_male_count FROM `va-bucket` WHERE type='va' AND va_gender='Male' OR va_gender='male' OR va_gender='M' OR va_gender='m'")
    for row in bucket.n1ql_query(query_va_male):
        res.append(row['va_male_count'])

    query_va_female = N1QLQuery("SELECT COUNT(*) AS va_female_count FROM `va-bucket` WHERE type='va' AND va_gender='Female' OR va_gender='female' OR va_gender='F' OR va_gender='f'")
    for row in bucket.n1ql_query(query_va_female):
        res.append(row['va_female_count'])

    return res

def get_farmers_by_gender():
    #global res
    res =[]
    query_va_male = N1QLQuery("SELECT COUNT(*) AS va_male_count FROM `va-bucket` WHERE type='farmer' AND farmer_gender='Male' OR farmer_gender='male' OR farmer_gender='M' OR farmer_gender='m'")
    for row in bucket.n1ql_query(query_va_male):
        res.append(row['va_male_count'])

    query_va_female = N1QLQuery("SELECT COUNT(*) AS va_female_count FROM `va-bucket` WHERE type='farmer' AND farmer_gender='Female' OR farmer_gender='female' OR farmer_gender='F' OR farmer_gender='f'")
    for row in bucket.n1ql_query(query_va_female):
        res.append(row['va_female_count'])

    return res

def get_agents_and_farmers_per_district():
    districts = ["Gulu","Lira","Amuru","Omoro","Arua"]
    va_res =[]
    farmer_res =[]
    result={}
    for distr in districts:
        query_district_vas = N1QLQuery("SELECT COUNT(*) AS distr_cnt FROM `va-bucket` WHERE type='va' AND va_district='%s' GROUP BY va_district" % distr)
        for row in bucket.n1ql_query(query_district_vas):
            va_res.append(row['distr_cnt'])
    for distr in districts:
        query_district_farmers = N1QLQuery("SELECT COUNT(*) AS distr_cnt FROM `va-bucket` WHERE type='farmer' AND farmer_district='%s' GROUP BY farmer_district" % distr)
        for row in bucket.n1ql_query(query_district_farmers):
            farmer_res.append(row['distr_cnt'])
    result['districts']=districts
    result['vas_per_district']=va_res
    result['farmers_per_district']=farmer_res

    return result

def get_top_performing_vas():
    return 0

def get_va_services_per_district_per_month():
    return 0


def get_all_dashboard():
    result = {}
    result['dashboard_totals']=get_dashboard_totals()
    result['va_genders']=get_vas_by_gender()
    result['farmer_genders']=get_farmers_by_gender()
    result['agents_and_farmers_per_district']=get_agents_and_farmers_per_district()
    return result

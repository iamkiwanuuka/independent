
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>EzyAgric | TecnoServe</title>
    <!--app page links-->
    <link rel="stylesheet" href="css/bootstrap.css" id="color-switcher-link">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <!--<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">-->
<!-- App CSS (includes Bootstrap & Bootstrap Layout) -->
<link type="text/css" href="css/app.min.css" rel="stylesheet">

<link href="images/icon" rel="stylesheet"  >
<link rel="icon" href="images/ak.jpg" type="image/x-icon" />

<link type="text/css" href="css/custom.css" rel="stylesheet">


<!--pop-up css-->
<!--<link href="css/pop_up.css" rel="stylesheet">-->


<!--sweetalert css-->
<!--<link href="css/sweetalert2.css" rel="stylesheet">-->



    <style>
        body {
            font-family: 'calibri';
        }

        .fa-btn {
            margin-right: 6px;
        }
        .material-icons{
          font-size: 18px;
          margin-right: 7px;
          padding-top: 7px;
        }
        
    </style>
</head>
<body>
<!--Nav Bar-->
<nav class="navbar navbar-default navbar-static-top">
        <div class="container">
            <div class="navbar-header"> 

                <!-- Branding Image -->
                <a class="navbar-brand" href="#">
                    <img src="images/ak.jpg" height="50px" >
                </a>
            </div>
            

            
            <div class="collapse navbar-collapse" id="app-navbar-collapse">
                <!-- Left Side Of Navbar -->
                <ul class="nav navbar-nav">
                    <li><a href="#" style="color: #ffffff;">EzyAgric</a></li>
                </ul>

                <!-- Right Side Of Navbar -->
                <ul class="nav navbar-nav navbar-right">
                    <!-- Authentication Links -->
                    
                        <!--<li><a href="#">McAnna</a></li>-->
                        <li><a href="#">Akorion Admin</a></li>
                    
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                
                            </a>

                            <ul class="dropdown-menu" role="menu">
                                <li><a href="#"><i class="fa fa-btn fa-sign-out"></i>Logout</a></li>
                            </ul>
                        </li>
                    
                </ul>
            </div>
        </div>
    </nav>
<!--Nav Bar Ends here-->

<!-- Sidebar -->
  <div class="sidebar sidebar-left sidebar-visible-md-up sidebar-size-3 sidebar-dark bg-primary sidebar-visible" style="margin-top: 57px;" id="sidebar" data-scrollable="">

    <!-- Brand -->
    <a href="#" style="text-decoration:none;" class="sidebar-brand sidebar-brand-bg sidebar-brand-border">Technoserve | STRYDE</a>


    <!--<ul class="sidebar-menu sm-active-button-bg sm-bordered">
      <li class="sidebar-menu-item">
        <a class="sidebar-menu-button" href="#">smartAgric</a>
      </li>
    </ul>-->
<!--<i class="material-icons">apps</i>-->
    <div class="sidebar-heading" id="sidebar-dashboard" ><i class="fa fa-btn fa-sign-out"></i>Dashboard</div><hr>
    <div class="sidebar-heading" id="sidebar-assets" data-toggle='collapse' data-target="#div-to-collapse" aria-expanded="true"><i class="fa fa-btn fa-sign-out"></i>Village Agents</div><hr> 
    <ul class="sidebar-menu sm-active-button-bg" id="div-to-collapse" style="margin-left:12px;">

      <li class="sidebar-menu-item">
        <a href="#" class="sidebar-menu-button" data-toggle="dropdown" id="sidebar-view-agent">View</a>
      </li>

      <li class="sidebar-menu-item">
        <a href="#" class="sidebar-menu-button" data-toggle="dropdown" id="sidebar-add-agent">Add</a>
      </li>

      <li class="sidebar-menu-item">
        <a href="#" class="sidebar-menu-button" data-toggle="dropdown" id="sidebar-upload-agent">Upload</a>
       </li>
       <!--<li class="sidebar-menu-item">
        <a href="#" class="sidebar-menu-button" data-toggle="dropdown" id="sidebar-biz-counsellor">Business Counsellor</a>
       </li>-->

       <li class="sidebar-menu-item">
        <a href="#" class="sidebar-menu-button" data-toggle="dropdown" id="sidebar-orders"><b>Orders</b></a>
       </li>
        <hr/>
    </ul>
    

  
    <div class="sidebar-heading" id="sidebar-view-farmer"><i class="fa fa-btn fa-sign-out"></i>Farmers</div>
    <hr/>
    <div class="sidebar-heading" id="sidebar-reports"><i class="fa fa-btn fa-sign-out"></i>Reports</div>
    <hr/>
    <div class="sidebar-heading" id="sidebar-suppliers"><i class="fa fa-btn fa-sign-out"></i>Training</div>
    <hr/>
        <ul class="sidebar-menu sm-active-button-bg" style="margin-left:12px;">

              <li class="sidebar-menu-item" id="sidebar-add-training">
                <a href="#" class="sidebar-menu-button" data-toggle="dropdown">Set Training</a>
              </li>

              <li class="sidebar-menu-item" id="sidebar-training-list">
                <a href="#" class="sidebar-menu-button" data-toggle="dropdown">View Training List</a>
              </li>

            </ul>
            
        <hr/>

    <div class="sidebar-heading" id="sidebar-commissions"><i class="fa fa-btn fa-sign-out"></i>Commissions</div>
    <hr/>
       <!-- <ul class="sidebar-menu sm-active-button-bg" style="margin-left:12px;">

              <li class="sidebar-menu-item" id="sidebar-set-commission">
                <a href="#" class="sidebar-menu-button" data-toggle="dropdown">Commission</a>
              </li>

            </ul>
            
        <hr/>-->
    
  </div>
  <!-- // END Sidebar -->

<!--MAIN PANEL STARTS HERE-->
<div class="main-panel">
  
<div>
<!--MAIN PANEL ENDS HERE-->



<script src="js/jquery-2.2.3.min.js"></script>
<script type="text/javascript" src="js/Chart.min.js"></script>
<script type="text/javascript" src="js/index.js"></script>

<script>
    $( document ).ready(function() {

        //$( ".main-panel" ).load('pages/homepage.html');
        $( ".main-panel" ).load('pages/dashboardpage.html');

        //ON SIDEBAR DASHBOARD CLICKED
        $( "#sidebar-dashboard" ).click(function() {

                $( ".main-panel" ).load('pages/dashboardpage.html');
        });

        //ON SIDEBAR REPORTS CLICKED
        $( "#sidebar-reports" ).click(function() {

                $( ".main-panel" ).load('pages/reportpage.html');
        });

        //ON SIDEBAR VIEW VILLAGE AGENT CLICKED
        $( "#sidebar-view-agent" ).click(function() {

                $( ".main-panel" ).load('pages/viewagentspage.html');
        });

        //ON SIDEBAR ADD VILLAGE AGENT CLICKED
        $( "#sidebar-add-agent" ).click(function() {

                $( ".main-panel" ).load('pages/addagentpage.html');
        });

        //ON SIDEBAR VIEW FARMER CLICKED
        $( "#sidebar-view-farmer" ).click(function() {

                $( ".main-panel" ).load('pages/viewfarmerspage.html');
        });

            //ON SIDEBAR SET/ADD TRAINING  CLICKED
        $( "#sidebar-add-training" ).click(function() {

                $( ".main-panel" ).load('pages/addtrainingpage.html');
        });

            //ON SIDEBAR SET/ADD TRAINING  CLICKED
        $( "#sidebar-orders" ).click(function() {

                $( ".main-panel" ).load('pages/vieworderspage.html');
        });

          //ON SIDEBAR SET/ADD TRAINING  CLICKED
        $( "#sidebar-training-list" ).click(function() {

                $( ".main-panel" ).load('pages/viewtraininglistpage.html');
        });

        

    });

   

    </script>

  <script src="js/jscript.js"></script>

<!--sidebar js-->
<script src="js/bootstrap.min.js"></script>
<!--<script src="js/modernizr-2.6.2.min.js"></script>
<script src="js/owl.carousel.js"></script>

<script src="js/sweetalert2.js"></script>-->

</body>
</html>




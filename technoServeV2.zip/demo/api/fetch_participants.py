from couchbase.n1ql import N1QLQuery
from config import serverBucket
from couchbase.views.iterator import View
bucket = serverBucket()
va_view = View(bucket, "dev_technoServe","vas")

#SELECT vaId, count(type) from `va-bucket` WHERE type='farmer' GROUP BY vaId;
def get_all_vas():
    #global res
    res =[]
    query_va = N1QLQuery("SELECT * FROM `test` WHERE type='va' AND vaId like 'AK/DP/0006%'")
    for row in bucket.n1ql_query(query_va):
        res.append(row['test'])
    return res
    #res ={}
    #cnt = 0
    #for row in View(bucket, "dev_KYF_KYA","vas", limit=10, reduce=False, inclusive_end=False):
        #cnt +=1
        #res[cnt]= row
    #return res


def get_all_farmers():
    #global res
    res =[]
    query_va = N1QLQuery("SELECT * FROM `test` WHERE type='farmer' AND vaId like 'AK/DP/0006%'")
    for row in bucket.n1ql_query(query_va):
        res.append(row['test'])
    return res
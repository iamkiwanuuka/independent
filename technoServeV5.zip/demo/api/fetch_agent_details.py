from couchbase.n1ql import N1QLQuery
from config import serverBucket
bucket = serverBucket()

#SELECT vaId, count(type) from `va-bucket` WHERE type='farmer' GROUP BY vaId;
def get_va_details():
    #global res
    res ={}
    vaId = 'AK/DP/0005/0003'
    query_va = N1QLQuery("SELECT * FROM `va-bucket` WHERE type='va' AND vaId='%s' LIMIT 1" %vaId)
    for row in va_bucket.n1ql_query(query_va):
        res.update(row['va-bucket'])
    return res

def get_farmers_profiled_by_va():
    res =[]
    vaId = 'AK/DP/0005/0003'
    query_va = N1QLQuery("SELECT * FROM `va-bucket` WHERE type='farmer' AND vaId='%s'" %vaId)
    for row in va_bucket.n1ql_query(query_va):
        res.append(row['va-bucket'])
    return res

def get_breakdown_of_inputs():
    return 0

def get_agent_commission_earned():
    return 0

def get_all_va_data():
    result={}
    result['va_details']=get_va_details()
    result['farmers_profiled_by_va']=get_farmers_profiled_by_va()
    return result

